-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- 主機: 127.0.0.1:3306
-- 產生時間： 2019-07-15 07:34:06
-- 伺服器版本: 5.7.23
-- PHP 版本： 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `dd101g1`
--

-- --------------------------------------------------------

--
-- 資料表結構 `administrator`
--

DROP TABLE IF EXISTS `administrator`;
CREATE TABLE IF NOT EXISTS `administrator` (
  `admin_no` int(11) NOT NULL,
  `admin_name` varchar(5) NOT NULL,
  `admin_id` varchar(11) NOT NULL,
  `admin_psw` varchar(11) NOT NULL,
  PRIMARY KEY (`admin_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `card`
--

DROP TABLE IF EXISTS `card`;
CREATE TABLE IF NOT EXISTS `card` (
  `card_no` int(11) NOT NULL,
  `customized_product_no` int(11) NOT NULL,
  PRIMARY KEY (`card_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `comment_record`
--

DROP TABLE IF EXISTS `comment_record`;
CREATE TABLE IF NOT EXISTS `comment_record` (
  `comment_no` int(11) NOT NULL,
  `comment_mem_no` int(11) NOT NULL,
  `contest_no` int(11) NOT NULL,
  `comment` varchar(100) NOT NULL,
  `comment_date` date NOT NULL,
  PRIMARY KEY (`comment_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `contest`
--

DROP TABLE IF EXISTS `contest`;
CREATE TABLE IF NOT EXISTS `contest` (
  `contest_no` int(11) NOT NULL,
  `contest_time` date NOT NULL,
  `mem_no` int(11) NOT NULL,
  `custom_no` int(11) NOT NULL,
  `number_votes` int(11) NOT NULL,
  `ranking` int(11) NOT NULL,
  PRIMARY KEY (`contest_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `customized_product`
--

DROP TABLE IF EXISTS `customized_product`;
CREATE TABLE IF NOT EXISTS `customized_product` (
  `customized_product_no` int(11) NOT NULL,
  `mem_no` int(11) NOT NULL,
  `card_no` int(11) NOT NULL,
  `choco_name` varchar(6) NOT NULL,
  `choco_shape_no` int(11) NOT NULL,
  `choco_base_no` int(10) NOT NULL,
  `choco_flavor_no` int(10) NOT NULL,
  `choco_eye_no` int(10) NOT NULL,
  `accs_no` int(10) NOT NULL,
  `choco_img_src` varchar(50) NOT NULL,
  `choco_price` int(10) NOT NULL,
  `order_successful` tinyint(1) NOT NULL COMMENT '1:完成購買;0:未完成購買',
  `subtotal` int(10) NOT NULL,
  `award_status` tinyint(1) NOT NULL,
  `card_pattern` varchar(10) NOT NULL,
  `font_pattern` varchar(10) NOT NULL,
  `decoration` varchar(10) NOT NULL,
  `img_src1` varchar(50) NOT NULL,
  `img_src2` varchar(50) NOT NULL,
  `card_price` int(11) NOT NULL,
  PRIMARY KEY (`customized_product_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `favorites`
--

DROP TABLE IF EXISTS `favorites`;
CREATE TABLE IF NOT EXISTS `favorites` (
  `favorites_no` int(11) NOT NULL,
  `mem_no` int(11) NOT NULL,
  `contest_no` int(11) NOT NULL,
  `classic_product_no` int(11) NOT NULL,
  PRIMARY KEY (`favorites_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `member`
--

DROP TABLE IF EXISTS `member`;
CREATE TABLE IF NOT EXISTS `member` (
  `mem_no` int(11) NOT NULL,
  `mem_name` varchar(11) NOT NULL,
  `mem_id` varchar(8) NOT NULL,
  `mem_psw` varchar(8) NOT NULL,
  `mem_email` varchar(30) NOT NULL,
  `mem_tel` char(10) NOT NULL,
  `mem_birth` date NOT NULL,
  `mem_credit` char(20) NOT NULL,
  `mem_address` varchar(20) NOT NULL,
  `mem_headshot` varchar(20) NOT NULL,
  `mem_status` tinyint(1) NOT NULL COMMENT '1:正常;0:停權',
  `mem_point` int(11) NOT NULL,
  `mem_vote_num` int(11) NOT NULL,
  `vote_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `order_list`
--

DROP TABLE IF EXISTS `order_list`;
CREATE TABLE IF NOT EXISTS `order_list` (
  `order_list_no` int(11) NOT NULL,
  `customized_product_no` int(11) NOT NULL,
  `classic_product_no` int(11) NOT NULL,
  `product_qty` int(11) NOT NULL,
  `product_price` int(11) NOT NULL,
  PRIMARY KEY (`order_list_no`),
  KEY `classic_product_no` (`classic_product_no`),
  KEY `customized_product_no` (`customized_product_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `order_master`
--

DROP TABLE IF EXISTS `order_master`;
CREATE TABLE IF NOT EXISTS `order_master` (
  `order_no` int(11) NOT NULL,
  `mem_no` int(11) NOT NULL,
  `credit_card_no` int(11) NOT NULL,
  `order_time` date NOT NULL,
  `order_amount` int(11) NOT NULL,
  `shipping_status` tinyint(1) NOT NULL COMMENT '1:已出貨;0:未出貨',
  `payment_status` tinyint(1) NOT NULL COMMENT '1:已付款;0:未付款'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `report`
--

DROP TABLE IF EXISTS `report`;
CREATE TABLE IF NOT EXISTS `report` (
  `report_no` int(11) NOT NULL,
  `comment_no` int(11) NOT NULL,
  `report_mem_no` int(11) NOT NULL,
  `report_reason` varchar(100) NOT NULL,
  `report_time` date NOT NULL,
  `report_status` tinyint(1) NOT NULL COMMENT '1:已處理;0:未處理',
  PRIMARY KEY (`report_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `robot`
--

DROP TABLE IF EXISTS `robot`;
CREATE TABLE IF NOT EXISTS `robot` (
  `keyword_no` int(10) NOT NULL,
  `keyword` varchar(10) NOT NULL,
  `keyword_respond` varchar(50) NOT NULL,
  PRIMARY KEY (`keyword_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 資料表結構 `test_boren`
--

DROP TABLE IF EXISTS `test_boren`;
CREATE TABLE IF NOT EXISTS `test_boren` (
  `姓名` varchar(6) NOT NULL,
  `123` int(11) NOT NULL,
  `456` int(11) NOT NULL,
  `789` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `test_boren`
--

INSERT INTO `test_boren` (`姓名`, `123`, `456`, `789`) VALUES
('陳柏仁', 111, 222, 333),
('陳柏仁', 111, 222, 333),
('', 999, 888, 777);

-- --------------------------------------------------------

--
-- 資料表結構 `test_classic_products`
--

DROP TABLE IF EXISTS `test_classic_products`;
CREATE TABLE IF NOT EXISTS `test_classic_products` (
  `classic_product_no` int(11) NOT NULL AUTO_INCREMENT,
  `classic_product_name` varchar(30) NOT NULL DEFAULT '',
  `product_price` int(11) DEFAULT NULL,
  `product_img_src` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`classic_product_no`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `test_classic_products`
--

INSERT INTO `test_classic_products` (`classic_product_no`, `classic_product_name`, `product_price`, `product_img_src`) VALUES
(1, 'choco1', 110, '1.gif'),
(2, 'choco2', 600, '2.gif'),
(3, 'choco3', 510, '3.gif'),
(4, 'choco4', 200, '4.gif'),
(5, 'choco5', 600, '5.gif');

-- --------------------------------------------------------

--
-- 資料表結構 `test_member`
--

DROP TABLE IF EXISTS `test_member`;
CREATE TABLE IF NOT EXISTS `test_member` (
  `mem_no` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `mem_name` varchar(10) DEFAULT NULL,
  `mem_id` varchar(8) DEFAULT NULL,
  `mem_psw` varchar(8) DEFAULT NULL,
  `mem_email` varchar(50) DEFAULT NULL,
  `mem_birth` date DEFAULT NULL,
  `mem_tel` varchar(10) DEFAULT NULL,
  `mem_credit` char(16) NOT NULL DEFAULT '0',
  `mem_address` varchar(30) DEFAULT NULL,
  `mem_headshot` varchar(20) DEFAULT NULL,
  `mem_status` char(1) NOT NULL DEFAULT '',
  `mem_point` int(11) DEFAULT NULL,
  PRIMARY KEY (`mem_no`),
  UNIQUE KEY `mem_id` (`mem_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `test_member`
--

INSERT INTO `test_member` (`mem_no`, `mem_name`, `mem_id`, `mem_psw`, `mem_email`, `mem_birth`, `mem_tel`, `mem_credit`, `mem_address`, `mem_headshot`, `mem_status`, `mem_point`) VALUES
(1, 'penny', 'penny', '111', 'i750307@iii.org.tw', '1960-08-08', '03-4257383', '0111111111', 'taipei', '8.gif', '1', 10),
(2, 'iris', 'iris', '111', 'amy@nctu.edu.tw', '1998-01-01', '03-4257387', '0111111112', 'taipei', '5.gif', '1', 20),
(3, '帥帥', 'Handsome', '111', 'handsome@gmail.com', '1960-01-01', '0933168168', '0111111113', 'taipei', '6.gif', '1', 30),
(4, 'HandsomeBO', '222', 'handsome', '1999-01-01', '0000-00-00', '111111113', 'taipei', '6.gif', '1', '3', 0);

-- --------------------------------------------------------

--
-- 資料表結構 `test_order_list`
--

DROP TABLE IF EXISTS `test_order_list`;
CREATE TABLE IF NOT EXISTS `test_order_list` (
  `order_list_no` int(11) NOT NULL DEFAULT '0',
  `order_no` int(11) NOT NULL DEFAULT '0',
  `customized_product_no` smallint(6) NOT NULL DEFAULT '0',
  `classic_product_no` smallint(6) NOT NULL DEFAULT '0',
  `product_qty` smallint(6) NOT NULL DEFAULT '0',
  `product_price` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_list_no`),
  KEY `customized_product_no` (`customized_product_no`),
  KEY `classic_product_no` (`classic_product_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `test_order_list`
--

INSERT INTO `test_order_list` (`order_list_no`, `order_no`, `customized_product_no`, `classic_product_no`, `product_qty`, `product_price`) VALUES
(1, 2, 1, 3, 12, 350),
(2, 4, 1, 4, 13, 360),
(3, 3, 2, 5, 14, 370),
(4, 6, 3, 6, 15, 380);

-- --------------------------------------------------------

--
-- 資料表結構 `test_order_master`
--

DROP TABLE IF EXISTS `test_order_master`;
CREATE TABLE IF NOT EXISTS `test_order_master` (
  `order_no` int(11) NOT NULL,
  `mem_no` smallint(6) NOT NULL DEFAULT '0',
  `credit_card_no` int(16) NOT NULL DEFAULT '0',
  `order_time` datetime DEFAULT NULL,
  `order_amount` int(11) NOT NULL DEFAULT '0',
  `shipping_status` char(1) NOT NULL DEFAULT '',
  `payment_status` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `test_order_master`
--

INSERT INTO `test_order_master` (`order_no`, `mem_no`, `credit_card_no`, `order_time`, `order_amount`, `shipping_status`, `payment_status`) VALUES
(1, 1, 4330044, '2008-10-20 00:00:00', 300, '1', '0');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
